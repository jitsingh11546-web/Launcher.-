package com.example.launcher

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*

class MainActivity : Activity() {

    private var apps: List<ResolveInfo> = emptyList()
    private lateinit var gestures: android.view.GestureDetector
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            @Suppress("DEPRECATION")
            setOnApplyWindowInsetsListener { v, i ->
                v.setPadding(0, i.systemWindowInsetTop, 0, i.systemWindowInsetBottom); i
            }
        }
        root.addView(TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            textSize = 56f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.create("sans-serif-thin", android.graphics.Typeface.NORMAL)
            setPadding(dp(24), dp(24), 0, 0)
        })
        root.addView(TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            textSize = 15f; setTextColor(0xCCFFFFFF.toInt()); setPadding(dp(26), 0, 0, dp(12))
        })

        val grid = GridView(this).apply {
            numColumns = 4; selector = ColorDrawable(Color.TRANSPARENT)
            adapter = object : BaseAdapter() {
                override fun getCount() = apps.size
                override fun getItem(p: Int) = apps[p]
                override fun getItemId(p: Int) = p.toLong()
                override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                    val ri = apps[p]
                    return LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                        setPadding(dp(4), dp(12), dp(4), dp(12))
                        addView(ImageView(context).apply {
                            setImageDrawable(ri.loadIcon(packageManager))
                            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
                        })
                        addView(TextView(context).apply {
                            text = ri.loadLabel(packageManager); setTextColor(Color.WHITE)
                            textSize = 11f; maxLines = 1; gravity = Gravity.CENTER
                            ellipsize = android.text.TextUtils.TruncateAt.END
                            setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(0, dp(6), 0, 0)
                        })
                    }
                }
            }
            setOnItemClickListener { _, _, p, _ -> openApp(apps[p]) }
            setOnItemLongClickListener { _, _, p, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:${apps[p].activityInfo.packageName}")))
                true
            }
        }
        root.addView(grid, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(root)
        this.grid = grid

        // Swipe down on the clock area to open the control center
        gestures = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && e1.y < dp(220) && e2.y - e1.y > dp(80) && vy > 600) {
                    ControlCenter(this@MainActivity).show(); return true
                }
                return false
            }
        })

        // One-time setup: overlay permission lets the lock screen start from the background
        if (!Settings.canDrawOverlays(this))
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, LockService::class.java))
    }

    private lateinit var grid: GridView

    override fun onResume() {
        super.onResume()
        // Every launchable app, system apps included
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = packageManager.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        (grid.adapter as BaseAdapter).notifyDataSetChanged()
    }

    private fun openApp(ri: ResolveInfo) {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev); return super.dispatchTouchEvent(ev)
    }

    @Deprecated("Launcher stays on home")
    override fun onBackPressed() {}
}

class ControlCenter(private val a: Activity) : Dialog(a, android.R.style.Theme_Translucent_NoTitleBar) {

    companion object { var torchOn = false }

    private fun dp(v: Int) = (v * a.resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val panel = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(16), dp(12), dp(12))
            isClickable = true
            background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(0xF2171B26.toInt()) }
        }
        val tiles = GridLayout(a).apply { columnCount = 4 }

        fun go(i: Intent) { dismiss(); a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

        tiles.addView(tile("Wi-Fi") { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) })
        tiles.addView(tile("Bluetooth") { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })
        tiles.addView(tile("Airplane") { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) })
        tiles.addView(tile(if (torchOn) "Torch on" else "Torch") { t ->
            val cm = a.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id != null) {
                torchOn = !torchOn; cm.setTorchMode(id, torchOn)
                t.text = if (torchOn) "Torch on" else "Torch"
                (t.background as GradientDrawable).setColor(if (torchOn) 0xFF3D6BFF.toInt() else 0xFF2A3040.toInt())
            }
        }.also { if (torchOn) (it.background as GradientDrawable).setColor(0xFF3D6BFF.toInt()) })
        tiles.addView(tile("Rotate") {
            if (Settings.System.canWrite(a)) {
                val cr = a.contentResolver
                val cur = Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1)
                Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1 - cur)
                Toast.makeText(a, if (cur == 1) "Rotation locked" else "Auto-rotate on", Toast.LENGTH_SHORT).show()
            } else askWrite()
        })
        tiles.addView(tile("Lock") { dismiss(); a.startActivity(Intent(a, LockActivity::class.java)) })
        tiles.addView(tile("Camera") { go(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) })
        tiles.addView(tile("Settings") { go(Intent(Settings.ACTION_SETTINGS)) })
        panel.addView(tiles)

        val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        panel.addView(label("Brightness"))
        panel.addView(slider(255, Settings.System.getInt(a.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)) { p ->
            if (Settings.System.canWrite(a)) {
                Settings.System.putInt(a.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(a.contentResolver, Settings.System.SCREEN_BRIGHTNESS, p.coerceAtLeast(1))
            } else askWrite()
        })
        panel.addView(label("Volume"))
        panel.addView(slider(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), am.getStreamVolume(AudioManager.STREAM_MUSIC)) {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, it, 0)
        })

        val root = FrameLayout(a).apply {
            setBackgroundColor(0x99000000.toInt()); setOnClickListener { dismiss() }
            addView(panel, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP).apply {
                setMargins(dp(10), dp(40), dp(10), 0)
            })
        }
        setContentView(root)
        window?.setLayout(MATCH_PARENT, MATCH_PARENT)
    }

    private fun askWrite() {
        a.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${a.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun tile(text: String, onTap: (TextView) -> Unit) = TextView(a).apply {
        this.text = text; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 12f
        background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0xFF2A3040.toInt()) }
        layoutParams = GridLayout.LayoutParams().apply {
            width = 0; height = dp(72)
            columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
        setOnClickListener { onTap(this) }
    }

    private fun label(t: String) = TextView(a).apply {
        text = t; setTextColor(0xAAFFFFFF.toInt()); textSize = 12f; setPadding(dp(8), dp(12), 0, 0)
    }

    private fun slider(max: Int, cur: Int, onChange: (Int) -> Unit) = SeekBar(a).apply {
        this.max = max; progress = cur; setPadding(dp(8), dp(12), dp(8), dp(12))
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }
}
